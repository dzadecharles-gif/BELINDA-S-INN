/* =========================================================================
   BELINDA'S INN — APP LOGIC
   ========================================================================= */
(function(){
  "use strict";

  /* ---------- state ---------- */
  let cart = [];               // { lineId, itemId, name, unitPrice, qty, mods, notes }
  let activeCategory = "all";
  let searchTerm = "";
  let fulfillment = "delivery"; // 'delivery' | 'pickup'
  let pendingItem = null;       // item being customized in the modal
  let pendingModalState = { qty: 1, protein: null, extras: [] };

  const money = n => "GH₵" + Number(n).toLocaleString("en-GH");
  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.from(document.querySelectorAll(sel));

  /* ---------- restaurant open/closed ---------- */
  function isRestaurantOpen(){
    if (!RESTAURANT.isOpen) return false;
    const h = new Date().getHours();
    return h >= RESTAURANT.openHour && h < RESTAURANT.closeHour;
  }

  function initBusinessInfo(){
    const open = isRestaurantOpen();
    $("#closedBannerHours").textContent = RESTAURANT.hoursText;
    $("#closedBanner").classList.toggle("show", !open);

    $("#heroAddress").textContent = RESTAURANT.address;
    $("#heroPhone").textContent = RESTAURANT.phone;
    $("#heroHours").textContent = RESTAURANT.hoursText;

    $("#infoAddress").textContent = RESTAURANT.address;
    $("#infoPhone").textContent = RESTAURANT.phone;
    $("#infoHours").textContent = RESTAURANT.hoursText;
    $("#infoStatus").textContent = open ? "Open now" : "Closed now";
    $("#infoStatusIcon").textContent = open ? "🟢" : "🔴";

    $("#footerName").textContent = RESTAURANT.name;
    $("#footerTagline").textContent = RESTAURANT.tagline;
    $("#footerPhone").textContent = "📞 " + RESTAURANT.phone;
    $("#footerAddress").textContent = "📍 " + RESTAURANT.address;
    $("#footerHours").textContent = "🕗 " + RESTAURANT.hoursText;
    $("#footerYear").textContent = new Date().getFullYear();

    const telHref = "tel:+233" + RESTAURANT.phone.replace(/\D/g,"").replace(/^0/,"");
    $("#callBtnAbout").href = telHref;
    $("#callBtnCard").href = telHref;

    const mapsHref = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(RESTAURANT.address);
    $("#directionsBtn").href = mapsHref;

    const waGeneric = "https://wa.me/" + RESTAURANT.whatsapp + "?text=" + encodeURIComponent("Hi Belinda's Inn, I'd like to place an order.");
    $("#waBtnAbout").href = waGeneric;

    $("#confirmPhone").textContent = RESTAURANT.phone;

    if (!open){
      $("#checkoutClosedBanner").style.display = "block";
    }
  }

  /* ---------- delivery zones ---------- */
  function populateZones(){
    const sel = $("#custZone");
    sel.innerHTML = "";
    DELIVERY_ZONES.filter(z => z.active).forEach(z => {
      const opt = document.createElement("option");
      opt.value = z.id;
      opt.textContent = `${z.name} — ${money(z.fee)} · ~${z.etaMins} min`;
      sel.appendChild(opt);
    });
  }
  function getZone(id){ return DELIVERY_ZONES.find(z => z.id === id); }

  /* ---------- menu rendering ---------- */
  function itemMatchesSearch(item, term){
    if (!term) return true;
    const t = term.toLowerCase();
    return item.name.toLowerCase().includes(t) || item.description.toLowerCase().includes(t);
  }

  function renderFilters(){
    const row = $("#filterRow");
    const all = [{ id: "all", label: "All" }, ...CATEGORIES];
    row.innerHTML = "";
    all.forEach(cat => {
      const btn = document.createElement("button");
      btn.className = "filter-chip";
      btn.type = "button";
      btn.textContent = cat.label;
      btn.setAttribute("aria-pressed", cat.id === activeCategory ? "true" : "false");
      btn.addEventListener("click", () => {
        activeCategory = cat.id;
        renderFilters();
        renderMenu();
      });
      row.appendChild(btn);
    });
  }

  function renderMenu(){
    const container = $("#menuGroups");
    container.innerHTML = "";
    let totalShown = 0;

    const cats = activeCategory === "all" ? CATEGORIES : CATEGORIES.filter(c => c.id === activeCategory);

    cats.forEach(cat => {
      const items = MENU_ITEMS.filter(i => i.category === cat.id && itemMatchesSearch(i, searchTerm));
      if (items.length === 0) return;
      totalShown += items.length;

      const group = document.createElement("div");
      group.className = "menu-group";
      const heading = document.createElement("h3");
      heading.textContent = cat.label;
      if (cat.ageRestricted){
        const tag = document.createElement("span");
        tag.className = "age-tag";
        tag.textContent = "18+ ONLY";
        heading.appendChild(tag);
      }
      group.appendChild(heading);

      const grid = document.createElement("div");
      grid.className = "menu-grid";
      items.forEach(item => grid.appendChild(renderItemCard(item)));
      group.appendChild(grid);
      container.appendChild(group);
    });

    $("#noResults").style.display = totalShown === 0 ? "block" : "none";
  }

  function renderItemCard(item){
    const card = document.createElement("article");
    card.className = "item-card";

    const photo = document.createElement("div");
    photo.className = "item-photo";
    photo.textContent = item.name.charAt(0);
    if (!item.available){
      const badge = document.createElement("span");
      badge.className = "sold-out-badge";
      badge.textContent = "SOLD OUT";
      photo.appendChild(badge);
    }
    card.appendChild(photo);

    const body = document.createElement("div");
    body.className = "item-body";
    body.innerHTML = `
      <h4>${item.name}</h4>
      <p>${item.description}</p>
      <div class="item-foot">
        <span class="item-price">${money(item.price)}</span>
        <span class="item-status ${item.available ? "" : "unavailable"}">${item.available ? "AVAILABLE" : "SOLD OUT"}</span>
      </div>
    `;
    const btn = document.createElement("button");
    btn.className = "add-btn";
    btn.textContent = item.available ? "Add to Order" : "Sold Out";
    btn.disabled = !item.available;
    btn.addEventListener("click", () => openItemModal(item));
    body.appendChild(btn);
    card.appendChild(body);

    return card;
  }

  /* ---------- item customization modal ---------- */
  function openItemModal(item){
    pendingItem = item;
    pendingModalState = { qty: 1, protein: null, extras: [] };

    $("#itemModalTitle").textContent = item.name;
    $("#itemModalDesc").textContent = item.description;
    $("#itemNotes").value = "";
    $("#itemQtyVal").textContent = "1";

    const optWrap = $("#itemModalOptions");
    optWrap.innerHTML = "";

    if (item.customizations && item.customizations.protein){
      const group = document.createElement("div");
      group.className = "option-group";
      const label = document.createElement("p");
      label.className = "opt-label";
      label.textContent = item.customizations.protein.label;
      group.appendChild(label);

      const choiceWrap = document.createElement("div");
      choiceWrap.className = "pill-choice";
      item.customizations.protein.options.forEach((opt, idx) => {
        const lbl = document.createElement("label");
        lbl.innerHTML = `<input type="radio" name="protein" value="${opt}" ${idx===0?"checked":""}><span>${opt}</span>`;
        choiceWrap.appendChild(lbl);
      });
      group.appendChild(choiceWrap);
      optWrap.appendChild(group);
      pendingModalState.protein = item.customizations.protein.options[0];

      choiceWrap.addEventListener("change", e => {
        if (e.target.name === "protein"){ pendingModalState.protein = e.target.value; updateModalPrice(); }
      });
    }

    if (item.customizations && item.customizations.extras){
      const group = document.createElement("div");
      group.className = "option-group";
      const label = document.createElement("p");
      label.className = "opt-label";
      label.textContent = item.customizations.extras.label;
      group.appendChild(label);

      const choiceWrap = document.createElement("div");
      choiceWrap.className = "pill-choice";
      item.customizations.extras.options.forEach(opt => {
        const lbl = document.createElement("label");
        lbl.innerHTML = `<input type="checkbox" name="extra" value="${opt.name}" data-price="${opt.price}"><span>${opt.name} (+${money(opt.price)})</span>`;
        choiceWrap.appendChild(lbl);
      });
      group.appendChild(choiceWrap);
      optWrap.appendChild(group);

      choiceWrap.addEventListener("change", () => {
        pendingModalState.extras = Array.from(choiceWrap.querySelectorAll("input:checked"))
          .map(inp => ({ name: inp.value, price: Number(inp.dataset.price) }));
        updateModalPrice();
      });
    }

    updateModalPrice();
    openModal("itemModal");
  }

  function currentModalUnitPrice(){
    let price = pendingItem.price;
    pendingModalState.extras.forEach(e => price += e.price);
    return price;
  }

  function updateModalPrice(){
    const total = currentModalUnitPrice() * pendingModalState.qty;
    $("#itemModalAdd").textContent = `Add to Order — ${money(total)}`;
  }

  $("#itemQtyMinus").addEventListener("click", () => {
    pendingModalState.qty = Math.max(1, pendingModalState.qty - 1);
    $("#itemQtyVal").textContent = pendingModalState.qty;
    updateModalPrice();
  });
  $("#itemQtyPlus").addEventListener("click", () => {
    pendingModalState.qty += 1;
    $("#itemQtyVal").textContent = pendingModalState.qty;
    updateModalPrice();
  });

  $("#itemModalAdd").addEventListener("click", () => {
    const mods = [];
    if (pendingModalState.protein) mods.push(pendingModalState.protein);
    pendingModalState.extras.forEach(e => mods.push(`+ ${e.name}`));
    const notes = $("#itemNotes").value.trim();

    cart.push({
      lineId: "L" + Date.now() + Math.floor(Math.random()*1000),
      itemId: pendingItem.id,
      name: pendingItem.name,
      unitPrice: currentModalUnitPrice(),
      qty: pendingModalState.qty,
      mods,
      notes
    });

    closeModal("itemModal");
    renderCart();
    showToast(`${pendingItem.name} added to your order`);
  });

  /* ---------- cart ---------- */
  function cartSubtotal(){
    return cart.reduce((sum, l) => sum + l.unitPrice * l.qty, 0);
  }
  function deliveryFee(){
    if (fulfillment !== "delivery") return 0;
    const zone = getZone($("#custZone").value);
    return zone ? zone.fee : 0;
  }
  function cartCount(){
    return cart.reduce((sum, l) => sum + l.qty, 0);
  }

  function renderCart(){
    const body = $("#cartBody");
    const foot = $("#cartFoot");
    const count = cartCount();

    $("#cartCount").style.display = count > 0 ? "flex" : "none";
    $("#cartCount").textContent = count;
    $("#stickyCartBar").classList.toggle("show", count > 0);
    $("#stickyCartCount").textContent = `${count} item${count===1?"":"s"}`;
    $("#stickyCartTotal").textContent = money(cartSubtotal());

    if (cart.length === 0){
      body.innerHTML = `<div class="empty-state"><span class="ic">🛒</span><p>Your cart is empty.<br>Add something delicious from the menu.</p></div>`;
      foot.style.display = "none";
      return;
    }

    body.innerHTML = "";
    cart.forEach(line => {
      const el = document.createElement("div");
      el.className = "cart-line";
      el.innerHTML = `
        <div class="thumb">${line.name.charAt(0)}</div>
        <div class="cl-body">
          <h5>${line.name}</h5>
          <div class="cl-mods">${[...line.mods, line.notes ? `Note: ${line.notes}` : ""].filter(Boolean).join(" · ") || "&nbsp;"}</div>
          <div class="cl-foot">
            <div class="qty-stepper" data-line="${line.lineId}">
              <button type="button" data-action="dec" aria-label="Decrease quantity">−</button>
              <span>${line.qty}</span>
              <button type="button" data-action="inc" aria-label="Increase quantity">+</button>
            </div>
            <span class="cl-price">${money(line.unitPrice * line.qty)}</span>
          </div>
          <button class="remove-link" data-remove="${line.lineId}">Remove</button>
        </div>
      `;
      body.appendChild(el);
    });

    body.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", () => {
        const lineId = btn.closest("[data-line]").dataset.line;
        const line = cart.find(l => l.lineId === lineId);
        if (!line) return;
        if (btn.dataset.action === "inc") line.qty += 1;
        if (btn.dataset.action === "dec") line.qty = Math.max(1, line.qty - 1);
        renderCart();
      });
    });
    body.querySelectorAll("[data-remove]").forEach(btn => {
      btn.addEventListener("click", () => {
        cart = cart.filter(l => l.lineId !== btn.dataset.remove);
        renderCart();
        showToast("Item removed");
      });
    });

    foot.style.display = "block";
    $("#cartSubtotal").textContent = money(cartSubtotal());
    $("#cartGrandTotal").textContent = money(cartSubtotal() + deliveryFee());
  }

  /* ---------- drawer / modal open-close ---------- */
  function openDrawer(){
    $("#cartDrawer").classList.add("open");
    $("#overlay").classList.add("show");
  }
  function closeDrawer(){
    $("#cartDrawer").classList.remove("open");
    $("#overlay").classList.remove("show");
  }
  function openModal(id){
    $("#" + id).classList.add("open");
    $("#overlay").classList.add("show");
  }
  function closeModal(id){
    $("#" + id).classList.remove("open");
    if (!$("#cartDrawer").classList.contains("open")) $("#overlay").classList.remove("show");
  }

  $("#cartToggle").addEventListener("click", openDrawer);
  $("#cartClose").addEventListener("click", closeDrawer);
  $("#stickyCartBar").addEventListener("click", openDrawer);
  $("#overlay").addEventListener("click", () => {
    closeDrawer();
    $$(".modal.open").forEach(m => closeModal(m.id));
  });
  $$("[data-close]").forEach(btn => btn.addEventListener("click", () => closeModal(btn.dataset.close)));

  /* ---------- nav ---------- */
  $("#navToggle").addEventListener("click", () => {
    const nav = $("#mobileNav");
    const willOpen = !nav.classList.contains("open");
    nav.classList.toggle("open", willOpen);
    $("#navToggle").setAttribute("aria-expanded", String(willOpen));
  });
  $$("#mobileNav a").forEach(a => a.addEventListener("click", () => $("#mobileNav").classList.remove("open")));

  /* ---------- search & filters ---------- */
  let searchDebounce;
  $("#menuSearch").addEventListener("input", e => {
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(() => {
      searchTerm = e.target.value;
      renderMenu();
    }, 120);
  });

  /* ---------- checkout: fulfillment toggle ---------- */
  $("#fulfillDelivery").addEventListener("click", () => setFulfillment("delivery"));
  $("#fulfillPickup").addEventListener("click", () => setFulfillment("pickup"));

  function setFulfillment(mode){
    fulfillment = mode;
    $("#fulfillDelivery").classList.toggle("active", mode === "delivery");
    $("#fulfillPickup").classList.toggle("active", mode === "pickup");
    $("#deliveryFields").style.display = mode === "delivery" ? "block" : "none";
    updateCheckoutSummary();
  }

  /* ---------- checkout open ---------- */
  $("#checkoutBtn").addEventListener("click", () => {
    if (cart.length === 0) return;
    closeDrawer();
    populateZones();
    setFulfillment(fulfillment);
    updateCheckoutSummary();
    openModal("checkoutModal");
  });
  $("#custZone").addEventListener("change", updateCheckoutSummary);

  function updateCheckoutSummary(){
    const sub = cartSubtotal();
    const fee = deliveryFee();
    $("#checkoutSummary").innerHTML = `
      <div class="totals-row"><span>Subtotal</span><span>${money(sub)}</span></div>
      <div class="totals-row"><span>${fulfillment === "delivery" ? "Delivery fee" : "Pickup"}</span><span>${fulfillment === "delivery" ? money(fee) : "GH₵0"}</span></div>
      <div class="totals-row grand"><span>Total</span><span>${money(sub + fee)}</span></div>
    `;
  }

  /* ---------- use my location ---------- */
  $("#useLocationBtn").addEventListener("click", () => {
    if (!navigator.geolocation){
      $("#locationStatus").textContent = "Location isn't supported on this device — please type your address.";
      return;
    }
    $("#locationStatus").textContent = "Getting your location…";
    navigator.geolocation.getCurrentPosition(
      pos => {
        const { latitude, longitude } = pos.coords;
        $("#locationStatus").textContent = `Location captured (${latitude.toFixed(4)}, ${longitude.toFixed(4)}). Please still add a short address or landmark below.`;
      },
      () => { $("#locationStatus").textContent = "Couldn't get your location — please type your address instead."; },
      { timeout: 8000 }
    );
  });

  /* ---------- validation ---------- */
  function setFieldError(id, hasError){
    $("#" + id).closest(".field").classList.toggle("has-error", hasError);
  }
  function validatePhone(v){
    const digits = v.replace(/\D/g, "");
    return digits.length >= 9;
  }
  function validateCheckoutForm(){
    let valid = true;
    const name = $("#custName").value.trim();
    const phone = $("#custPhone").value.trim();

    setFieldError("custName", !name); if (!name) valid = false;
    setFieldError("custPhone", !validatePhone(phone)); if (!validatePhone(phone)) valid = false;

    if (fulfillment === "delivery"){
      const addr = $("#custAddress").value.trim();
      setFieldError("custAddress", !addr); if (!addr) valid = false;
    }
    return valid;
  }

  /* ---------- order number & building order text ---------- */
  function generateOrderNumber(){
    const n = Math.floor(1000 + Math.random() * 9000);
    return "BI-" + n;
  }

  function buildOrderSummaryText(orderNo){
    const lines = cart.map(l => {
      const mods = l.mods.length ? ` (${l.mods.join(", ")})` : "";
      const note = l.notes ? ` [Note: ${l.notes}]` : "";
      return `• ${l.name}${mods} x${l.qty} — ${money(l.unitPrice * l.qty)}${note}`;
    }).join("\n");

    const name = $("#custName").value.trim();
    const phone = $("#custPhone").value.trim();
    const payment = document.querySelector('input[name="payment"]:checked').value;
    const paymentLabel = { momo: "Mobile Money", cash: "Cash on Delivery/Pickup", card: "Card" }[payment];

    const sub = cartSubtotal();
    const fee = deliveryFee();

    let fulfillmentBlock = "";
    if (fulfillment === "delivery"){
      const zone = getZone($("#custZone").value);
      const addr = $("#custAddress").value.trim();
      const dirs = $("#custDirections").value.trim();
      fulfillmentBlock =
`Delivery to: ${zone ? zone.name : ""}
Address: ${addr}${dirs ? `\nDirections: ${dirs}` : ""}`;
    } else {
      fulfillmentBlock = "Pickup at: Belinda's Inn, " + RESTAURANT.address;
    }

    return `NEW ORDER — ${orderNo}
Belinda's Inn

Customer: ${name}
Phone: ${phone}

${fulfillmentBlock}

Items:
${lines}

Subtotal: ${money(sub)}
${fulfillment === "delivery" ? `Delivery fee: ${money(fee)}\n` : ""}Total: ${money(sub + fee)}

Payment method: ${paymentLabel}
Fulfillment: ${fulfillment === "delivery" ? "Delivery" : "Pickup"}`;
  }

  /* ---------- place order (in-browser confirmation) ---------- */
  $("#checkoutForm").addEventListener("submit", e => {
    e.preventDefault();
    if (!validateCheckoutForm()) return;

    const orderNo = generateOrderNumber();
    closeModal("checkoutModal");
    $("#confirmOrderNo").textContent = orderNo;

    const summary = buildOrderSummaryText(orderNo);
    const waUrl = "https://wa.me/" + RESTAURANT.whatsapp + "?text=" + encodeURIComponent(summary);
    $("#confirmWaBtn").href = waUrl;

    openModal("confirmModal");

    cart = [];
    renderCart();
  });

  $("#whatsappOrderBtn").addEventListener("click", () => {
    if (!validateCheckoutForm()) return;
    const orderNo = generateOrderNumber();
    const summary = buildOrderSummaryText(orderNo);
    const waUrl = "https://wa.me/" + RESTAURANT.whatsapp + "?text=" + encodeURIComponent(summary);
    window.open(waUrl, "_blank", "noopener");
  });

  $("#confirmOrderAgain").addEventListener("click", () => {
    closeModal("confirmModal");
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ---------- toast ---------- */
  let toastTimer;
  function showToast(msg){
    const el = $("#toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
  }

  /* ---------- init ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    initBusinessInfo();
    populateZones();
    renderFilters();
    renderMenu();
    renderCart();
    setFulfillment("delivery");
  });
})();

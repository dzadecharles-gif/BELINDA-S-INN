/* =========================================================================
   BELINDA'S INN — SITE DATA
   -------------------------------------------------------------------------
   This file is the closest thing to an "admin dashboard" this static site
   has. Edit the values below to update the menu, prices, hours, and
   delivery zones — no other files need to change.

   Everything under "SAMPLE MENU DATA" is placeholder content for
   development and must be replaced with Belinda's Inn's official menu,
   prices, and photos before this goes live for real customers.
   ========================================================================= */

const RESTAURANT = {
  name: "Belinda's Inn",
  tagline: "Great Food. Great Taste. Delivered to You.",
  address: "E Akuffo Addo Road, Kwesimintsim, Western Region, Ghana",
  phone: "020 533 9216",
  // WhatsApp number in international format, no + or spaces (Ghana = 233)
  whatsapp: "233205339216",
  hoursText: "8:00 AM – 11:00 PM",
  openHour: 8,   // 24hr clock
  closeHour: 23,
  // Flip this to false to show the "currently closed" banner site-wide.
  isOpen: true
};

/* Delivery zones — admin-configurable list. Fees are illustrative until
   Belinda's Inn confirms real delivery pricing. */
const DELIVERY_ZONES = [
  { id: "adiembra", name: "Adiembra", fee: 15, etaMins: 30, minOrder: 0, active: true },
  { id: "kwesimintsim", name: "Kwesimintsim", fee: 10, etaMins: 20, minOrder: 0, active: true },
  { id: "takoradi", name: "Takoradi (Town)", fee: 25, etaMins: 45, minOrder: 0, active: true },
  { id: "effia", name: "Effia", fee: 20, etaMins: 35, minOrder: 0, active: true },
  { id: "anaji", name: "Anaji", fee: 25, etaMins: 40, minOrder: 0, active: true },
  { id: "sekondi", name: "Sekondi", fee: 30, etaMins: 50, minOrder: 0, active: true }
];

/* Menu categories, in display order */
const CATEGORIES = [
  { id: "local", label: "Local Food" },
  { id: "continental", label: "Continental" },
  { id: "cocktails", label: "Cocktails" },
  { id: "beverages", label: "Beverages" },
  { id: "alcohol", label: "Alcohol", ageRestricted: true }
];

/* SAMPLE MENU DATA — REPLACE WITH OFFICIAL BELINDA'S INN MENU
   price: whole cedis (GH₵). available: false shows "Sold out" and blocks
   ordering. customizations are optional per item. */
const MENU_ITEMS = [
  // ---- LOCAL FOOD ----
  {
    id: "fufu-light-soup", category: "local",
    name: "Fufu & Light Soup",
    description: "Smooth pounded fufu with a peppery, herb-forward light soup.",
    price: 180, available: true,
    customizations: {
      protein: { label: "Choose protein", options: ["Chicken", "Fish", "Beef", "Goat"] },
      extras: { label: "Extras", options: [
        { name: "Extra fufu", price: 15 },
        { name: "Extra meat", price: 25 },
        { name: "Extra fish", price: 20 }
      ]}
    }
  },
  {
    id: "banku-tilapia", category: "local",
    name: "Banku & Grilled Tilapia",
    description: "Fermented corn-and-cassava banku with a whole grilled tilapia and pepper sauce.",
    price: 250, available: true,
    customizations: {
      extras: { label: "Extras", options: [
        { name: "Extra banku", price: 15 },
        { name: "Extra pepper sauce", price: 10 },
        { name: "Side salad", price: 20 }
      ]}
    }
  },
  {
    id: "waakye", category: "local",
    name: "Waakye Special",
    description: "Rice and beans with shito, gari, boiled egg, and your choice of protein.",
    price: 160, available: true,
    customizations: {
      protein: { label: "Choose protein", options: ["Chicken", "Beef", "Fish", "Sausage"] },
      extras: { label: "Extras", options: [
        { name: "Extra egg", price: 8 },
        { name: "Extra shito", price: 10 },
        { name: "Wele (cow skin)", price: 15 }
      ]}
    }
  },
  {
    id: "jollof-chicken", category: "local",
    name: "Jollof Rice & Chicken",
    description: "Smoky party-style jollof rice with grilled or fried chicken.",
    price: 170, available: true,
    customizations: {
      protein: { label: "Choose protein", options: ["Grilled chicken", "Fried chicken", "Beef", "Fish"] },
      extras: { label: "Extras", options: [
        { name: "Extra chicken", price: 30 },
        { name: "Extra rice", price: 15 },
        { name: "Coleslaw", price: 15 }
      ]}
    }
  },
  {
    id: "red-red", category: "local",
    name: "Red Red & Fried Plantain",
    description: "Black-eyed bean stew in palm oil, served with sweet fried plantain.",
    price: 150, available: true
  },
  {
    id: "ampesi-kontomire", category: "local",
    name: "Ampesi & Kontomire Stew",
    description: "Boiled yam and plantain with a rich cocoyam-leaf stew.",
    price: 165, available: false
  },

  // ---- CONTINENTAL ----
  {
    id: "chicken-chips", category: "continental",
    name: "Chicken & Chips",
    description: "Crispy fried chicken with golden fries and a side salad.",
    price: 175, available: true,
    customizations: {
      extras: { label: "Extras", options: [
        { name: "Extra chips", price: 15 },
        { name: "Coleslaw", price: 15 },
        { name: "Extra sauce", price: 5 }
      ]}
    }
  },
  {
    id: "beef-steak", category: "continental",
    name: "Grilled Beef Steak",
    description: "Pepper-crusted beef steak, sautéed vegetables, mashed potato.",
    price: 320, available: true
  },
  {
    id: "spaghetti-bolognese", category: "continental",
    name: "Spaghetti Bolognese",
    description: "Slow-cooked minced beef ragù over al dente spaghetti.",
    price: 190, available: true
  },
  {
    id: "chicken-alfredo", category: "continental",
    name: "Chicken Alfredo",
    description: "Creamy alfredo pasta tossed with grilled chicken strips.",
    price: 210, available: true
  },
  {
    id: "club-sandwich", category: "continental",
    name: "Club Sandwich",
    description: "Triple-decker with chicken, egg, bacon, and fresh vegetables, served with fries.",
    price: 155, available: true
  },
  {
    id: "margherita-pizza", category: "continental",
    name: "Margherita Pizza",
    description: "Wood-fired style base, tomato, mozzarella, fresh basil.",
    price: 200, available: true
  },

  // ---- COCKTAILS ----
  {
    id: "mojito", category: "cocktails",
    name: "Classic Mojito",
    description: "White rum, fresh mint, lime, soda. Alcoholic — 18+ only.",
    price: 70, available: true
  },
  {
    id: "pina-colada", category: "cocktails",
    name: "Piña Colada",
    description: "Rum, coconut cream, pineapple juice. Alcoholic — 18+ only.",
    price: 75, available: true
  },
  {
    id: "virgin-mojito", category: "cocktails",
    name: "Virgin Mojito",
    description: "Fresh mint, lime, soda, a touch of sugar. Non-alcoholic.",
    price: 45, available: true
  },
  {
    id: "tropical-punch", category: "cocktails",
    name: "Tropical Fruit Punch",
    description: "Pineapple, passion fruit, orange, grenadine. Non-alcoholic.",
    price: 40, available: true
  },

  // ---- BEVERAGES ----
  { id: "sobolo", category: "beverages", name: "Sobolo (Hibiscus)", description: "Chilled house-made hibiscus drink.", price: 20, available: true },
  { id: "pineapple-juice", category: "beverages", name: "Fresh Pineapple Juice", description: "Locally sourced, no added sugar.", price: 25, available: true },
  { id: "coconut-drink", category: "beverages", name: "Fresh Coconut Water", description: "Served chilled, straight from the nut.", price: 25, available: true },
  { id: "coca-cola", category: "beverages", name: "Coca-Cola", description: "35cl bottle.", price: 20, available: true },
  { id: "bottled-water", category: "beverages", name: "Bottled Water", description: "75cl.", price: 20, available: true },
  { id: "malt", category: "beverages", name: "Malt Drink", description: "33cl bottle.", price: 22, available: true },

  // ---- ALCOHOL ----
  { id: "club-beer", category: "alcohol", name: "Club Beer", description: "60cl bottle. 18+ only.", price: 35, available: true },
  { id: "star-beer", category: "alcohol", name: "Star Beer", description: "60cl bottle. 18+ only.", price: 35, available: true },
  { id: "house-wine-glass", category: "alcohol", name: "House Wine (Glass)", description: "Red or white. 18+ only.", price: 60, available: true },
  { id: "guinness", category: "alcohol", name: "Guinness Smooth", description: "60cl bottle. 18+ only.", price: 40, available: true }
];
